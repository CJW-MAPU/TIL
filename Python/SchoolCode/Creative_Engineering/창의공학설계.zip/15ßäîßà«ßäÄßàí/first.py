classes = ['1교시', '2교시', '3교시', '4교시', '5교시']

for item in classes:
    print(item)