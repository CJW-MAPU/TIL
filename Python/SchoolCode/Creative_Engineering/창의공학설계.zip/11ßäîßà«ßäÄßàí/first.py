score = int(input('input score : '))

if score >= 80:
    print('You Pass!!')
    print('Congratulation!!')

if score < 60:
    print('You Fail!!')
    print('Plz Retry!!')
