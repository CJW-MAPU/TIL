per_hour = int(input('주행 속도(km/h) : '))
hour = int(input('주행 시간(h) : '))
moving_distance = per_hour * hour
print(f'주행 거리 : {moving_distance} km')
