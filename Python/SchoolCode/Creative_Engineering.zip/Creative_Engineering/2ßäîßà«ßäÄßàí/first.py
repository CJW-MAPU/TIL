import turtle

t = turtle.Turtle()
t.shape('turtle')

for i in range(0, 3):
    t.forward(100)
    t.right(90)
t.forward(100)
t.circle(50)
