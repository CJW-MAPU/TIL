input_data = int(input('입력 값 : '))

if input_data % 2 == 0:
    print(f'{input_data}는 짝수 입니다.')
else:
    print(f'{input_data}는 홀수 입니다.')