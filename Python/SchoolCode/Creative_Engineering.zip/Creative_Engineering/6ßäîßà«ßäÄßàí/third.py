weight = float(input('몸무게(kg): '))
height = float(input('신장(m): '))
BMI = int(weight / (height * height))
print(f'BMI: {BMI}')