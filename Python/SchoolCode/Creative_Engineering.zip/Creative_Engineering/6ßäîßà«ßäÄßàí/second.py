width = int(input('가로 길이: '))
height = int(input('세로 길이: '))
print(f'넓이 : {width * height} cm^2')
